from . import network
class NANNetwork(network.Network):
    def __init__(self, nodeContainer: list):
        super().__init__(self)

    


        
