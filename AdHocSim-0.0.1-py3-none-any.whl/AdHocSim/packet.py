class Packet():
    def __init__(self, size, src, dest) -> None:
        self.size = size
        self.src = src
        self.dest = dest
       
        