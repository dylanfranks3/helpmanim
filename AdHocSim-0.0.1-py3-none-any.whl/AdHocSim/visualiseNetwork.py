from manim import *
from manim.utils.file_ops import open_file as open_media_file 


